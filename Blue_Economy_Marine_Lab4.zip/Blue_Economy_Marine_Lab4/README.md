# BlueGuard — Lab Activity #4

**Sector:** Blue Economy & Marine Innovation

- `index.html`, `style.css`, `script.js`: final single-page prototype
- `prompt-log.md`: Tasks 1–6 and reflection
- `outputs/task2-zero-shot/`: baseline example
- `outputs/task3-structured/`: place actual structured-prompt output here
- `outputs/task4a-fewshot/`: place actual few-shot output here
- `outputs/task4b-role/review.md`: role-assignment record
- `outputs/task5-analysis/diagnosis.md`: analysis and verification record

The prompts are ready to submit to GitHub Copilot. Replace placeholders with actual outputs, observations, and tests before submission. Open `index.html` in a browser to run the prototype. Images use remote URLs and need internet access.
