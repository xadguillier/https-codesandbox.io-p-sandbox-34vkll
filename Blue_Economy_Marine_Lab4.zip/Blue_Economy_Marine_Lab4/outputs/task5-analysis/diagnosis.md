# Task 5 — Structured Analysis and Refinement

**Note:** This is a template, not an actual Copilot diagnosis.

## Exact prompt
Review my BlueGuard prototype against these requirements: responsive layout, semantic HTML, search, category filtering, interactive marine-friendly checklist, pledge selection, accessible labels, and clear educational content. Identify the two most important issues in the supplied code. Recommend the smallest appropriate corrections and give a test procedure. Do not add a backend, database, authentication, or external APIs. Point to the relevant code when identifying an issue.

## Actual Copilot diagnosis
[PASTE THE ACTUAL DIAGNOSIS HERE.]

## Issue selected
[Record an issue confirmed by inspecting the code.]

## Correction applied
[Describe the exact code change made.]

## Verification procedure
1. Open `index.html` in a browser.
2. Search for “coral” and confirm only matching topics remain.
3. Test both category filters.
4. Check and uncheck actions; confirm the completion count changes.
5. Select and save a pledge; check the message.
6. Try saving without a selection.
7. Test keyboard access and mobile layout.

## Verification result
[Record only tests actually performed and their outcomes.]
