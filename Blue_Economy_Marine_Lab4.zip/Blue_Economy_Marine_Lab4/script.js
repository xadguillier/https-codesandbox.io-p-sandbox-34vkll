const search=document.querySelector("#search");
const cards=[...document.querySelectorAll(".topic")];
const filters=[...document.querySelectorAll(".filter")];
const actions=[...document.querySelectorAll(".action")];
let category="all";
function updateCards(){const query=search.value.trim().toLowerCase();let count=0;cards.forEach(card=>{const match=card.dataset.search.includes(query)&&(category==="all"||card.dataset.category===category);card.hidden=!match;if(match)count++;});document.querySelector("#empty").hidden=count>0;}
search.addEventListener("input",updateCards);
filters.forEach(button=>button.addEventListener("click",()=>{category=button.dataset.filter;filters.forEach(item=>item.classList.toggle("active",item===button));updateCards();}));
function updateProgress(){document.querySelector("#done").textContent=actions.filter(item=>item.checked).length;}
actions.forEach(item=>item.addEventListener("change",updateProgress));
document.querySelector("#save-pledge").addEventListener("click",()=>{const value=document.querySelector("#pledge-select").value;document.querySelector("#result").textContent=value?`Thank you! Your chosen pledge is: ${value}.`:"Please select a pledge before saving.";});
updateCards();updateProgress();
