# Hands-On Laboratory Activity #4
## Prompt, Observe, Refine: Effective Prompt Engineering for AI-Assisted Web Development

**Innovation sector:** Blue Economy & Marine Innovation  
**Project title:** BlueGuard: Marine Awareness for Coastal Communities  
**Student:** [Write your name]  
**Course:** Web Systems and Technologies

> Submit each prompt to GitHub Copilot and replace bracketed fields with actual outputs, observations, and test results. Example observations are not proof of what Copilot generated. Do not claim a test passed unless you performed it.

## Task 1 — Sector Selection

**Sector:** Blue Economy & Marine Innovation

**Local challenge:** Coastal residents and visitors need accessible information about marine habitats and simple ways to reduce harm to coastal environments. Information about coral reefs, mangroves, and responsible coastal behavior may be scattered across different sources.

**Target users:** Coastal residents, students, tourists, local environmental groups, and people interested in marine conservation.

**Proposed project:** BlueGuard, a responsive educational webpage that introduces marine habitats and encourages practical marine-friendly habits.

**Key features:**
1. Topic cards about coral reefs, mangroves, and sustainable coastal livelihoods.
2. Search and category filters for marine habitats and community topics.
3. An interactive checklist and personal marine-friendly pledge.

**Scope:** Semantic HTML, CSS, and vanilla JavaScript. No backend, database, authentication, or external APIs. This is educational content, not a live marine monitoring service.

## Task 2 — Zero-Shot Prompting

**Objective:** Observe the result of a basic prompt without examples or detailed constraints.

**Exact prompt:**
> Create a simple webpage about Blue Economy and Marine Innovation. Explain why protecting the ocean matters and list some ways people can help protect marine environments.

**Actual Copilot output:** Save the actual baseline under `outputs/task2-zero-shot/`. Summary: [REPLACE WITH ACTUAL OUTPUT].

**What worked:** [Example only: Check whether Copilot created a heading and basic marine conservation tips.]

**What needs improvement:** [Record missing features or design problems actually observed.]

**Next action / verification:** Open the generated page in a browser and preserve this version as the baseline.

## Task 3 — Anatomy of a Prompt (Structured Prompt)

**Objective:** Improve relevance using Role, Task, Context, Constraints, Expected Output, and Acceptance Criteria.

**Exact prompt:**
> Role: Act as a frontend web developer. Task: Build a responsive single-page website called “BlueGuard” about marine awareness and the blue economy. Context: Coastal communities, students, and visitors need simple information about marine habitats and responsible coastal behavior. Constraints: Use semantic HTML, CSS, and vanilla JavaScript only. Do not use frameworks, backend services, databases, authentication, or external APIs. Do not claim to show live marine conditions. Expected output: Provide `index.html`, `style.css`, and `script.js`. Include topic cards about coral reefs, mangroves, and sustainable coastal livelihoods; keyword search; category filters; an interactive marine-friendly checklist with a completion count; and a dropdown for choosing and saving a marine-friendly pledge. Acceptance criteria: The page must be readable on mobile; search and filters must update visible topics; checklist progress must update when boxes are checked; the pledge must display a helpful message; and controls must have labels and visible keyboard focus.

**Actual Copilot output:** Save the real files in `outputs/task3-structured/`: [REPLACE WITH ACTUAL OUTPUT SUMMARY].

**What worked:** [Compare the actual output with Task 2.]

**What needs improvement:** [Record missing features, errors, or usability issues actually found.]

**Next action / verification:** Test search, filters, checklist progress, pledge selection, keyboard access, and mobile layout.

## Task 4A — Few-Shot Prompting

**Objective:** Use examples to encourage consistent marine awareness entries.

**Exact prompt:**
> Create four additional marine awareness entries for my BlueGuard webpage using the same format as these examples:
>
> Example 1  
> Topic: Coral Reef Awareness  
> Category: Marine habitat  
> Description: Avoid touching coral and follow local guidance when visiting reef areas.
>
> Example 2  
> Topic: Mangrove Protection  
> Category: Marine habitat  
> Description: Keep waste away from mangrove areas and respect restoration activities.
>
> Generate four additional entries using exactly these fields: Topic, Category, and Description. Use concise educational wording suitable for coastal communities in the Philippines. Do not invent local statistics or claim to report live environmental conditions. Render the entries consistently and keep category filtering functional.

**Actual Copilot output:** Save actual output in `outputs/task4a-fewshot/`: [REPLACE WITH ACTUAL OUTPUT SUMMARY].

**What worked:** [Check if entries followed the same format.]

**What needs improvement:** [Record inconsistencies or unsupported claims.]

**Next action / verification:** Check every entry and test category filters.

## Task 4B — Role Assignment

**Objective:** Ask Copilot to review the interface from an accessibility specialist's perspective.

**Exact prompt:**
> Act as a frontend accessibility reviewer. Review my BlueGuard marine awareness webpage. Check semantic HTML, keyboard access, checkbox labels, image alternative text, responsive layout, and visual clarity. Identify the two most important issues in the supplied code and recommend small corrections without adding a backend or changing the project's scope. Explain how I can verify each correction.

**Actual Copilot response:** Save it in `outputs/task4b-role/review.md`: [REPLACE WITH ACTUAL RESPONSE].

**What worked:** [Describe relevant recommendations.]

**What needs improvement:** [Identify unclear or unsupported suggestions.]

**Next action / verification:** Apply a suitable correction and test keyboard navigation, labels, focus indicators, image descriptions, and mobile layout.

## Task 5 — Structured Analysis and Refinement

**Objective:** Identify an implementation weakness, apply a correction, and test it.

**Exact prompt:**
> Review my BlueGuard single-page prototype against these requirements: responsive layout, semantic HTML, search, category filtering, interactive marine-friendly checklist, pledge selection, accessible labels, and clear educational content. Identify the two most important issues in the supplied code. Recommend the smallest appropriate corrections and give a test procedure. Do not add a backend, database, authentication, or external APIs. Point to the relevant code when identifying an issue.

**Actual Copilot diagnosis:** Save the real response in `outputs/task5-analysis/diagnosis.md`: [REPLACE WITH ACTUAL RESPONSE].

**Issue selected:** [Describe an issue confirmed by inspecting the code.]

**Correction applied:** [Describe the exact change made.]

**Verification result:** [Record the steps and actual outcome.]

**Next action:** If the correction does not work, revise and test it again. An AI recommendation alone does not prove an issue existed or was fixed.

## Task 6 — Compare and Submit

| Technique | Observation based on actual results |
|---|---|
| Zero-shot | [What did Copilot assume or omit?] |
| Structured prompt | [What improved after adding context and constraints?] |
| Few-shot | [Did examples make the topic entries more consistent? Give evidence.] |
| Role assignment | [What accessibility concerns were identified?] |
| Structured analysis | [What correction was tested, and what was the result?] |

## Final Reflection

**Draft reflection — personalize it using your actual experiments:**

This activity helped me understand that the way I write a prompt affects the usefulness of AI-generated code. A simple prompt can be a starting point, but it may not include all the features required for a webpage. A structured prompt explains the target users, project context, technologies, and acceptance criteria more clearly. Few-shot prompting can help make marine awareness content consistent, while role assignment can reveal accessibility concerns. Structured analysis can guide me toward a specific correction, but I still need to inspect the code and test the result. I learned that GitHub Copilot can support frontend development, but I am responsible for checking the accuracy, accessibility, and functionality of the final project.

**Before submission:** Add specific examples from your actual Copilot outputs and tests.
